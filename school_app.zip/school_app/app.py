"""School management website (Flask + SQLAlchemy).
Edit the SCHOOL SETTINGS block below for your own school, then run: python app.py
Database: SQLite by default; set DATABASE_URL to use Microsoft SQL Server."""
import os
from datetime import date, datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import (LoginManager, UserMixin, login_user, logout_user,
                         login_required, current_user)
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func

# ===== SCHOOL SETTINGS: CHANGE THESE FOR YOUR OWN SCHOOL =====
SCHOOL = {"name": "YOUR SCHOOL NAME", "status": "Private",
          "location": "Town, Region, Country", "range": "Nursery to JHS"}
CLASSES = ["Nursery", "KG 1", "KG 2"] + [f"Basic {i}" for i in range(1, 10)]
THEME = {"main": "#14532d", "accent": "#c2410c", "light": "#fde68a"}  # header, buttons, header subtitle
# ==============================================================

ROLES = ["parent", "teacher", "proprietor", "headmaster", "admin"]

from jinja2 import DictLoader

TEMPLATES = {
    'base.html': r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ school.name }}</title></head>
<body style="margin:0;font:16px/1.5 Georgia,serif;background:#f6f7f4;color:#222">
<header style="background:#1d2b4f;color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
<div><b style="font-size:1.2rem;letter-spacing:.02em">{{ school.name }}</b>
<small style="display:block;color:#e4cf99">{{ school.status }} school · {{ school.location }} · {{ school.range }}</small></div>
{% if current_user.is_authenticated %}<div>{{ current_user.full_name }} ({{ current_user.role|capitalize }}) · <a href="{{ url_for('logout') }}" style="color:#fff">Sign out</a></div>{% endif %}
</header>
<main style="max-width:1000px;margin:24px auto;padding:0 16px">
{% for m in get_flashed_messages() %}<div style="background:#fff4d6;border:1px solid #b8861b;padding:8px 12px;border-radius:4px;margin-bottom:14px">{{ m }}</div>{% endfor %}
{% block body %}{% endblock %}
</main></body></html>
''',
    'login.html': r'''{% extends "base.html" %}{% block body %}
<section style="max-width:380px;margin:40px auto;background:#fff;border:1px solid #d9dccf;border-radius:6px;padding:20px 24px">
<h2 style="margin:0 0 12px;color:#1d2b4f;font-size:1.3rem">Sign in</h2>
<form method="post">
<label>Username<br><input name="username" required autofocus style="width:100%;padding:8px 10px;border:1px solid #aab;border-radius:4px;margin:3px 0 10px;font:inherit;box-sizing:border-box"></label>
<label>Password<br><input name="password" type="password" required style="width:100%;padding:8px 10px;border:1px solid #aab;border-radius:4px;margin:3px 0 10px;font:inherit;box-sizing:border-box"></label>
<button style="padding:9px 18px;background:#b8861b;color:#fff;border:1px solid #b8861b;border-radius:4px;font:inherit;cursor:pointer">Sign in</button>
</form></section>{% endblock %}
''',
    'dashboard.html': r'''{% extends "base.html" %}{% block body %}
{# Style codes are stored here once, then used as inline style="" attributes. Change a colour here and it changes everywhere. #}
{% set SEC = "background:#fff;border:1px solid #d9dccf;border-radius:6px;padding:16px 20px;margin-bottom:20px" %}
{% set H2 = "margin:0 0 10px;color:#1d2b4f;font-size:1.15rem" %}
{% set TBL = "width:100%;border-collapse:collapse;font-size:.95rem" %}
{% set TH = "text-align:left;padding:6px 8px;border-bottom:2px solid #d9dccf;color:#1d2b4f" %}
{% set TD = "text-align:left;padding:6px 8px;border-bottom:1px solid #d9dccf" %}
{% set INP = "padding:7px 9px;border:1px solid #aab;border-radius:4px;margin:3px 3px 3px 0;font:inherit" %}
{% set BTN = "padding:7px 14px;background:#b8861b;color:#fff;border:1px solid #b8861b;border-radius:4px;margin:3px 0;font:inherit;cursor:pointer" %}
{% set STAT = "background:#fff;border:1px solid #d9dccf;border-left:4px solid #b8861b;padding:10px 14px" %}
{% set NUM = "display:block;font-size:1.5rem;font-weight:bold;color:#1d2b4f" %}
{% set WRAP = "overflow-x:auto" %}
{% set r = current_user.role %}
<h1 style="color:#1d2b4f;font-size:1.6rem">{{ r|capitalize }} dashboard</h1>

{% if r in ['headmaster','proprietor','admin'] %}
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:20px">
<div style="{{ STAT }}"><span style="{{ NUM }}">{{ total_students }}</span>Students enrolled</div>
<div style="{{ STAT }}"><span style="{{ NUM }}">{{ staff|length }}</span>Teaching staff</div>
<div style="{{ STAT }}"><span style="{{ NUM }}">{{ att_today if att_today is not none else '-' }}{{ '%' if att_today is not none }}</span>Present today</div>
{% if r in ['proprietor','admin'] %}
<div style="{{ STAT }}"><span style="{{ NUM }}">GH₵ {{ '%.2f'|format(paid) }}</span>Fees collected</div>
<div style="{{ STAT }}"><span style="{{ NUM }}">GH₵ {{ '%.2f'|format(owing) }}</span>Fees outstanding</div>{% endif %}
</div>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Enrolment by class</h2><div style="{{ WRAP }}"><table style="{{ TBL }}"><tr><th style="{{ TH }}">Class</th><th style="{{ TH }}">Students</th></tr>
{% for c, n in per_class %}<tr><td style="{{ TD }}">{{ c }}</td><td style="{{ TD }}">{{ n }}</td></tr>{% endfor %}</table></div></section>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Teachers</h2><table style="{{ TBL }}"><tr><th style="{{ TH }}">Name</th><th style="{{ TH }}">Class</th><th style="{{ TH }}">Phone</th></tr>
{% for t in staff %}<tr><td style="{{ TD }}">{{ t.full_name }}</td><td style="{{ TD }}">{{ t.class_name or '-' }}</td><td style="{{ TD }}">{{ t.phone or '-' }}</td></tr>
{% else %}<tr><td colspan="3" style="{{ TD }}">No teachers added yet.</td></tr>{% endfor %}</table></section>
{% endif %}

{% if r == 'parent' %}
{% for c in children %}<section style="{{ SEC }}"><h2 style="{{ H2 }}">{{ c.student.name }} · {{ c.student.class_name }}</h2>
<p style="margin:0 0 10px">Admission no. {{ c.student.admission_no }} · Attendance: {{ c.attendance if c.attendance is not none else '-' }}{{ '%' if c.attendance is not none }}
· Fees paid GH₵ {{ '%.2f'|format(c.paid) }} of {{ '%.2f'|format(c.due) }} (balance GH₵ {{ '%.2f'|format(c.balance) }})</p>
<table style="{{ TBL }}"><tr><th style="{{ TH }}">Term</th><th style="{{ TH }}">Subject</th><th style="{{ TH }}">Score</th></tr>
{% for x in c.results %}<tr><td style="{{ TD }}">{{ x.term }}</td><td style="{{ TD }}">{{ x.subject }}</td><td style="{{ TD }}">{{ x.score }}</td></tr>
{% else %}<tr><td colspan="3" style="{{ TD }}">No results published yet.</td></tr>{% endfor %}</table></section>
{% else %}<section style="{{ SEC }}">No children are linked to your account yet. Please contact the school office.</section>{% endfor %}
{% endif %}

{% if r == 'teacher' %}
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Attendance for {{ current_user.class_name or 'no class assigned' }} · {{ today }}</h2>
<form method="post" action="{{ url_for('mark_attendance') }}"><table style="{{ TBL }}">
{% for s in students %}<tr><td style="{{ TD }}">{{ s.name }}</td><td style="{{ TD }}">
{% for o in ['present','late','absent'] %}<label style="margin-right:10px"><input type="radio" name="s{{ s.id }}" value="{{ o }}" {{ 'checked' if o=='present' }}> {{ o }}</label>{% endfor %}</td></tr>
{% else %}<tr><td style="{{ TD }}">No students in this class.</td></tr>{% endfor %}</table><button style="{{ BTN }}">Save attendance</button></form></section>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Enter a score</h2><form method="post" action="{{ url_for('add_score') }}">
<select name="student_id" required style="{{ INP }}">{% for s in students %}<option value="{{ s.id }}">{{ s.name }}</option>{% endfor %}</select>
<input name="subject" placeholder="Subject" required style="{{ INP }}"><input name="term" placeholder="Term, e.g. 2026 Term 1" required style="{{ INP }}">
<input name="score" type="number" step="0.1" min="0" max="100" placeholder="Score" required style="{{ INP }}"><button style="{{ BTN }}">Save score</button></form></section>
{% endif %}

{% if r == 'admin' %}
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Add a user</h2><form method="post" action="{{ url_for('add_user') }}">
<input name="full_name" placeholder="Full name" required style="{{ INP }}"><input name="username" placeholder="Username" required style="{{ INP }}">
<input name="password" type="password" placeholder="Password" required style="{{ INP }}"><input name="phone" placeholder="Phone" style="{{ INP }}">
<select name="role" style="{{ INP }}">{% for x in roles %}<option>{{ x }}</option>{% endfor %}</select>
<select name="class_name" style="{{ INP }}"><option value="">Class (teachers)</option>{% for c in classes %}<option>{{ c }}</option>{% endfor %}</select>
<button style="{{ BTN }}">Create user</button></form></section>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Add a student</h2><form method="post" action="{{ url_for('add_student') }}">
<input name="admission_no" placeholder="Admission no." required style="{{ INP }}"><input name="name" placeholder="Full name" required style="{{ INP }}">
<select name="class_name" style="{{ INP }}">{% for c in classes %}<option>{{ c }}</option>{% endfor %}</select>
<input name="parent_username" placeholder="Parent username" style="{{ INP }}"><button style="{{ BTN }}">Add student</button></form></section>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Record fees</h2><form method="post" action="{{ url_for('record_fee') }}">
<input name="admission_no" placeholder="Admission no." required style="{{ INP }}"><input name="term" placeholder="Term" required style="{{ INP }}">
<input name="amount_due" type="number" step="0.01" placeholder="Amount due" required style="{{ INP }}">
<input name="amount_paid" type="number" step="0.01" placeholder="Amount paid" required style="{{ INP }}"><button style="{{ BTN }}">Save fees</button></form></section>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Users</h2><div style="{{ WRAP }}"><table style="{{ TBL }}"><tr><th style="{{ TH }}">Name</th><th style="{{ TH }}">Username</th><th style="{{ TH }}">Role</th></tr>
{% for u in users %}<tr><td style="{{ TD }}">{{ u.full_name }}</td><td style="{{ TD }}">{{ u.username }}</td><td style="{{ TD }}">{{ u.role }}</td></tr>{% endfor %}</table></div></section>
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Students</h2><div style="{{ WRAP }}"><table style="{{ TBL }}"><tr><th style="{{ TH }}">Adm. no.</th><th style="{{ TH }}">Name</th><th style="{{ TH }}">Class</th></tr>
{% for s in students %}<tr><td style="{{ TD }}">{{ s.admission_no }}</td><td style="{{ TD }}">{{ s.name }}</td><td style="{{ TD }}">{{ s.class_name }}</td></tr>{% endfor %}</table></div></section>
{% endif %}

{% if r in ['headmaster','proprietor','admin'] %}
<section style="{{ SEC }}"><h2 style="{{ H2 }}">Post a notice</h2><form method="post" action="{{ url_for('post_notice') }}">
<input name="title" placeholder="Title" required style="{{ INP }};width:60%"><br><textarea name="body" rows="3" placeholder="Message" required style="{{ INP }};width:90%"></textarea><br><button style="{{ BTN }}">Post notice</button></form></section>
{% endif %}

<section style="{{ SEC }}"><h2 style="{{ H2 }}">School notices</h2>{% for n in notices %}<p style="margin:0 0 12px"><strong style="color:#1d2b4f">{{ n.title }}</strong> <small style="color:#666">{{ n.author }}, {{ n.created.strftime('%d %b %Y') }}</small><br>{{ n.body }}</p>
{% else %}<p style="margin:0">No notices yet.</p>{% endfor %}</section>
{% endblock %}
''',
}

TEMPLATES = {k: v.replace("#1d2b4f", THEME["main"]).replace("#b8861b", THEME["accent"]).replace("#e4cf99", THEME["light"]) for k, v in TEMPLATES.items()}
app = Flask(__name__)
app.jinja_loader = DictLoader(TEMPLATES)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-secret")
# SQL Server example:
# mssql+pyodbc://USER:PASS@SERVER/school_db?driver=ODBC+Driver+18+for+SQL+Server
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///school.db")
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(60), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    phone = db.Column(db.String(30))
    class_name = db.Column(db.String(20))  # class taught (teachers)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admission_no = db.Column(db.String(30), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    class_name = db.Column(db.String(20), nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey("user.id"))


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    day = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(10), nullable=False)  # present / absent / late


class Result(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    subject = db.Column(db.String(60), nullable=False)
    term = db.Column(db.String(20), nullable=False)
    score = db.Column(db.Float, nullable=False)


class Fee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    term = db.Column(db.String(20), nullable=False)
    amount_due = db.Column(db.Numeric(10, 2), nullable=False)
    amount_paid = db.Column(db.Numeric(10, 2), default=0)


class Notice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    body = db.Column(db.Text, nullable=False)
    author = db.Column(db.String(120))
    created = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(uid):
    return db.session.get(User, int(uid))


def role_required(*roles):
    def deco(f):
        @wraps(f)
        @login_required
        def wrapper(*a, **k):
            if current_user.role not in roles:
                abort(403)
            return f(*a, **k)
        return wrapper
    return deco


@app.context_processor
def inject():
    return {"school": SCHOOL, "classes": CLASSES, "roles": ROLES}


@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(username=request.form["username"].strip()).first()
        if u and check_password_hash(u.password_hash, request.form["password"]):
            login_user(u)
            return redirect(url_for("dashboard"))
        flash("Wrong username or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("login"))


def child_summary(s):
    recs = Attendance.query.filter_by(student_id=s.id).all()
    present = sum(1 for r in recs if r.status in ("present", "late"))
    fees = Fee.query.filter_by(student_id=s.id).all()
    due = sum(f.amount_due for f in fees)
    paid = sum(f.amount_paid or 0 for f in fees)
    return {"student": s, "attendance": round(100 * present / len(recs)) if recs else None,
            "results": Result.query.filter_by(student_id=s.id).order_by(Result.term, Result.subject).all(),
            "due": due, "paid": paid, "balance": due - paid}


def school_stats():
    per_class = dict(db.session.query(Student.class_name, func.count(Student.id))
                     .group_by(Student.class_name).all())
    recs = Attendance.query.filter_by(day=date.today()).all()
    present = sum(1 for r in recs if r.status in ("present", "late"))
    due = db.session.query(func.coalesce(func.sum(Fee.amount_due), 0)).scalar()
    paid = db.session.query(func.coalesce(func.sum(Fee.amount_paid), 0)).scalar()
    return {"total_students": Student.query.count(),
            "per_class": [(c, per_class.get(c, 0)) for c in CLASSES],
            "staff": User.query.filter_by(role="teacher").order_by(User.full_name).all(),
            "att_today": round(100 * present / len(recs)) if recs else None,
            "due": due, "paid": paid, "owing": due - paid}


@app.route("/dashboard")
@login_required
def dashboard():
    r, ctx = current_user.role, {}
    if r == "parent":
        ctx["children"] = [child_summary(s) for s in Student.query.filter_by(parent_id=current_user.id)]
    elif r == "teacher":
        ctx["students"] = Student.query.filter_by(class_name=current_user.class_name).order_by(Student.name).all()
        ctx["today"] = date.today()
    else:
        ctx.update(school_stats())
        if r == "admin":
            ctx["users"] = User.query.order_by(User.role, User.full_name).all()
            ctx["students"] = Student.query.order_by(Student.class_name, Student.name).all()
    ctx["notices"] = Notice.query.order_by(Notice.created.desc()).limit(5).all()
    return render_template("dashboard.html", **ctx)


@app.post("/teacher/attendance")
@role_required("teacher")
def mark_attendance():
    for s in Student.query.filter_by(class_name=current_user.class_name):
        status = request.form.get(f"s{s.id}")
        if status:
            rec = Attendance.query.filter_by(student_id=s.id, day=date.today()).first() \
                or Attendance(student_id=s.id, day=date.today(), status=status)
            rec.status = status
            db.session.add(rec)
    db.session.commit()
    flash("Attendance saved.")
    return redirect(url_for("dashboard"))


@app.post("/teacher/score")
@role_required("teacher")
def add_score():
    s = db.session.get(Student, int(request.form["student_id"]))
    if not s or s.class_name != current_user.class_name:
        abort(403)
    db.session.add(Result(student_id=s.id, subject=request.form["subject"].strip(),
                          term=request.form["term"].strip(), score=float(request.form["score"])))
    db.session.commit()
    flash("Score saved.")
    return redirect(url_for("dashboard"))


@app.post("/notice")
@role_required("headmaster", "proprietor", "admin")
def post_notice():
    db.session.add(Notice(title=request.form["title"], body=request.form["body"],
                          author=current_user.full_name))
    db.session.commit()
    flash("Notice posted.")
    return redirect(url_for("dashboard"))


@app.post("/admin/user")
@role_required("admin")
def add_user():
    f = request.form
    if User.query.filter_by(username=f["username"].strip()).first():
        flash("That username is taken.")
    else:
        db.session.add(User(username=f["username"].strip(), full_name=f["full_name"].strip(),
                            role=f["role"], phone=f.get("phone"), class_name=f.get("class_name") or None,
                            password_hash=generate_password_hash(f["password"])))
        db.session.commit()
        flash("User created.")
    return redirect(url_for("dashboard"))


@app.post("/admin/student")
@role_required("admin")
def add_student():
    f = request.form
    parent = User.query.filter_by(username=f.get("parent_username", "").strip(), role="parent").first()
    db.session.add(Student(admission_no=f["admission_no"].strip(), name=f["name"].strip(),
                           class_name=f["class_name"], parent_id=parent.id if parent else None))
    db.session.commit()
    flash("Student added." if parent else "Student added (no parent linked - check the username).")
    return redirect(url_for("dashboard"))


@app.post("/admin/fee")
@role_required("admin")
def record_fee():
    f = request.form
    s = Student.query.filter_by(admission_no=f["admission_no"].strip()).first()
    if not s:
        flash("No student with that admission number.")
    else:
        fee = Fee.query.filter_by(student_id=s.id, term=f["term"]).first() \
            or Fee(student_id=s.id, term=f["term"], amount_due=0, amount_paid=0)
        fee.amount_due = float(f["amount_due"])
        fee.amount_paid = float(f["amount_paid"])
        db.session.add(fee)
        db.session.commit()
        flash("Fee record saved.")
    return redirect(url_for("dashboard"))


@app.cli.command("init-db")
def init_db():
    """Create tables and a first admin: flask --app app init-db"""
    db.create_all()
    if not User.query.filter_by(username="admin").first():
        pw = os.getenv("ADMIN_PASSWORD", "ChangeMe123!")
        db.session.add(User(username="admin", full_name="System Admin", role="admin",
                            password_hash=generate_password_hash(pw)))
        db.session.commit()
        print("Created admin / " + pw + "  (change it after first login)")


if __name__ == "__main__":
    with app.app_context():
        init_db.callback()
    app.run(debug=True)
