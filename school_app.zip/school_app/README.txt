SCHOOL MANAGEMENT WEBSITE
1. Open app.py and edit the SCHOOL SETTINGS block near the top (name, location, classes, colours).
2. Install Python (tick "Add python.exe to PATH"), open this folder in VS Code, open a terminal.
3. pip install flask flask-sqlalchemy flask-login
4. python app.py
5. Open http://127.0.0.1:5000  login: admin / ChangeMe123!  (change it after logging in)
